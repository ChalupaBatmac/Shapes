
package shapestest;

/**
 *
 * @author Diego.Conterno001
 */
public class Shapes {
   public String shape;
   
}
