
package shapestest;

public enum EnumShape {
    X, XBOX, CIRCLE, BOX, EXIT
}