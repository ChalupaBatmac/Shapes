package shapestest;

public class ShapeObject {
    private X x;
    private Box b;
    private Xbox xb;
    private Circle c;
    
    public ShapeObject(){
        this.x = null;
        this.b = null;
        this.xb = null;
        this.c = null;
    }
    
    public void setShape(Object o){
        if(o.getClass() == X.class)
            x = (X)o;
        if(o.getClass() == Box.class)
            b = (Box)o;
        if(o.getClass() == Xbox.class)
            xb = (Xbox)o;
        if(o.getClass() == Circle.class)
            c = (Circle)c;
    }
    
    
}